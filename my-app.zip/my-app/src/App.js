import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div style={{color:"red"}}>
          <p>hello</p>

        </div>
      </header>
    </div>
  );
}

export default App;
